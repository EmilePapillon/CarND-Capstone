from keras.models import Sequential
from keras.layers import Lambda, Conv2D, Dropout, Flatten, Dense , MaxPooling2D
from keras.utils import plot_model
from keras.preprocessing.image import ImageDataGenerator, array_to_img, img_to_array, load_img
#from sklearn.utils import shuffle 
from os import listdir, path
import cv2
import numpy as np
import matplotlib.pyplot as plt
from random import randint

#make the model
model = Sequential()
model.add(Lambda(lambda x: (x-128)/128, input_shape = (32,32,3)))

model.add(Conv2D(128, (3, 3), padding="same", activation="relu"))
model.add(MaxPooling2D(pool_size=(2,2))) #leave ?	

model.add(Conv2D(64, (1, 1), padding="same", activation="relu"))
model.add(MaxPooling2D(pool_size=(2,2)))

model.add(Flatten())
model.add(Dense(32, kernel_initializer='normal', activation='relu'))
model.add(Dense(3, kernel_initializer='normal', activation='sigmoid'))

model.compile(loss='binary_crossentropy',
 optimizer='rmsprop',
 metrics=['accuracy'])
plot_model(model, to_file='model.png')
#import data for training and shuffle and split in training and validation sample sets
cwd = path.dirname(path.realpath(__file__))
path =cwd+'/Data_Traffic_lights'
data = []
for subdir in listdir(path):
	for file in listdir(path+'/'+subdir): 
                #make labels
		if subdir == '0' :
                        color = np.array([1, 0, 0])
                        str_name = 'red'
                elif subdir == '1':
                        color  = np.array([0, 1, 0])
                        str_name = 'yellow'
                else:
                        color = np.array([0, 0, 1])
                        str_name = 'green'
                filepath = path+'/'+subdir+'/'+file
                #print(filepath,' is a ',str_name,' light')
		data.append({'img_path':filepath, 'tl_state':color, 'string_name':str_name})

#print([cv2.imread(file['img_path']) for file in data].shape)
''' #note:  this would be for data augmentation later...
datagen = ImageDataGenerator(
        rotation_range=40,
        width_shift_range=0.2,
        height_shift_range=0.2,
        rescale=1./255,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest')
'''



X_train = np.stack([cv2.imread(file['img_path']) for file in data],axis=0)
y_train = np.array([file['tl_state'] for file in data])
fig,axes = plt.subplots(5,5)

fig.suptitle('25 random lights from the training set')
for i in range(25):
        idx=randint(0,1000)
        ax=axes[i%5,int(i/5)]
        ax.imshow(X_train[idx])
        ax.set_yticklabels([])
        ax.set_xticklabels([])
        ax.set_title(y_train[idx])
plt.subplots_adjust(hspace=0.5)

#train_samples, val_samples = train_test_split(shuffle(data), test_size=0.2) 
batch_size  = 32 

model.fit(X_train, y_train, batch_size=batch_size, epochs=15, validation_split=0.2, shuffle=True)

predict_images = np.stack([cv2.imread(file['img_path']) for file in data if file['string_name'] == 'green'],axis=0)
print('prediction',model.predict(predict_images))
model.save('./model.h5')
plt.show()
