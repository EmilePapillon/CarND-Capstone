from keras.models import load_model
from os import listdir, path
import numpy as np
import cv2
import matplotlib.pyplot as plt
from random import randint 

model=load_model('model.h5')


cwd = path.dirname(path.realpath(__file__))
path =cwd+'/Data_Traffic_lights'
filepaths = []
for subdir in listdir(path):
	for file in listdir(path+'/'+subdir): 
                #make labels
                filepath = path+'/'+subdir+'/'+file
                filepaths.append(filepath)

imgs=np.stack([cv2.imread(fp) for fp in filepaths],axis=0)
print(imgs.shape)

fig,axes = plt.subplots(5,5)
fig.suptitle('25 random lights from the test set')
colors = ['red', 'yellow', 'green']
for i in range(25):
        idx=randint(0,1000)
        ax=axes[i%5,int(i/5)]
        img = imgs[idx]
        ax.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))
        ax.set_yticklabels([])
        ax.set_xticklabels([])
        lbl=model.predict(np.array([img]))
        title=str(colors[np.argmax(lbl[0])])
        '''
        if lbl[0][0]:
                title = 'red'
        elif lbl[0][1]:
                title = 'yellow'
        else : title = 'green'
        '''
        ax.set_title(title)
plt.subplots_adjust(hspace=0.5)
plt.show()